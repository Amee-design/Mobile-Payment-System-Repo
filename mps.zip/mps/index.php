<?php session_start(); ?>
<?php include_once("src/dbcon.class.php"); ?>
<?php
$db = new dbCon();
?>
<?php include_once("src/registration.class.php"); ?>
<?php include_once("src/navigation.class.php"); ?>
<?php
$regForm = new registration($db);
?>
<?php
$nav = new navigation();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Mobile Payment System</title>
	<link rel="stylesheet" href="css/appCss.css">
</head>
<body>
<?php
$nav->navStart();
$nav->appendNav("index.php","Home");
$nav->appendNav("registration","Register");
$nav->appendNav("login","Login");
$nav->navEnd();
//check if user request is registration or login
if(isset($_GET['request']) && $_GET['request'] === "registration"){
	//display the registration form
	//call the reg class
	$regForm->displayRegForm();
} elseif(isset($_GET['request']) && $_GET['request'] === "login") {
	//display the login form
	//call the login class
	$regForm->displayLoginForm();
}

$regForm->registerCustomer();
$regForm->loginCustomer();
?>
</body>
</html>
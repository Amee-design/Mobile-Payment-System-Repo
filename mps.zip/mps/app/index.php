<?php 
session_start(); 
if(!isset($_SESSION['user'])){
	print '<script>location.assign("/mps");</script>';
}else{
	//do nothing
}
?>
<?php include_once("../src/dbcon.class.php"); ?>
<?php
$db = new dbCon();
?>
<?php include_once("../src/userActivityForms.class.php"); ?>
<?php include_once("../src/navigation.class.php"); ?>
<?php include_once("../src/userActivity.class.php"); ?>
<?php
$activityForm = new userActivityForms($db);
$userActivity = new userActivity($db);
?>
<?php
$nav = new navigation();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Mobile Payment System</title>
	<link rel="stylesheet" href="../css/appCss.css">
</head>
<body>
	<section>
		<h2>Welcome to your dashboard, <?=$_SESSION['user'];?><br>
			<b>Wallet Balance:</b> <?=$userActivity->getUserWallet();?></h2>
	</section>
<?php
$nav->navStart();
$nav->appendNav("#","Dashboard");
$nav->appendNav("wallet","Fund Wallet");
$nav->appendNav("complaints","Support Ticket");
$nav->appendNav("payBill","Pay Bill");
$nav->appendNav("logout","Logout");
$nav->navEnd();
//check if user request is registration or login
if(isset($_GET['request']) && $_GET['request'] === "wallet"){
	//display the registration form
	//call the reg class
	$activityForm->displayWalletForm();
} elseif(isset($_GET['request']) && $_GET['request'] === "updateWallet") {
	//display the login form
	//call the login class
	$activityForm->displayUpdateWalletForm();
}elseif(isset($_GET['request']) && $_GET['request'] === "logout"){
	$userActivity->logout();
}elseif(isset($_GET['request']) && $_GET['request'] === "complaints"){
	$activityForm->displayComplaintsWalletForm();
	$activityForm->fetchComplaints();
}elseif(isset($_GET['request']) && $_GET['request'] === "payBill"){
	$activityForm->displayBillForm();
	$activityForm->fetchBill();
}

$activityForm->submitWalletForm();
$activityForm->submitComplaintForm();
$activityForm->submitBill();
?>
</body>
</html>
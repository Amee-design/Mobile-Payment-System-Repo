<?php
//class navigation drawer
class navigation{
	public function __construct(){
		
	}
	public function navStart(){
		print "<nav>";
	}
	public function navEnd(){
		print "</nav>";
	}
	public function appendNav($link,$linkName){
		$this->link = $link;
		$this->linkName = $linkName;
		$link = '<a href="?request='.$this->link.'">'.$this->linkName.'</a>';
		print $link;
	}
}
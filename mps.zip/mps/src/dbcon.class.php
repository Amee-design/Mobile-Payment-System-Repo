<?php
/**
php class to connect to mps database
written by: Ameerah 
date: 14th Feb., 2021
**/
class dbCon{
	public function __construct(){
		$db_host = "localhost";
		$db_user = "root";
		$db_user_pw = "";
		$db_database = "mps";

		$db = new mysqli($db_host,$db_user,$db_user_pw,$db_database);
		$this->db = $db;
	}

	public function test_connection(){
		if($this->db){
			print "Successfully connected";
		}else{
			print "Something went wrong!";
		}
	}

	public function cleanInput($input){
		$this->input = $input;
		$this->input = htmlspecialchars($this->input);
		$this->input = addslashes($this->input);

		return $this->input;
	}

	public function saveData($sql){
		$this->sql = $sql;
		$this->status = $this->db->query($this->sql);
		if(!$this->status){
			return 0;
		}else{
			return 1;
		}
	}
	public function updateData($sql){
		$this->sql = $sql;
		$this->status = $this->db->query($this->sql);
		if(!$this->status){
			return 0;
		}else{
			return 1;
		}
	}
	public function getData($sql){
		$this->sql = $sql;
		$this->set = array();
		$this->status = $this->db->query($this->sql);
		while($row = $this->status->fetch_assoc()){
			$this->set[] = $row;
		}
		return $this->set;
	}
	public function checkSql($sql){
		$this->sql = $sql;
		if(!$this->db->query($this->sql)){
			print $this->db->error;
		}else{
			//silence is golden
		}
	}

	public function countRows($sql){
		$this->sql = $sql;
		try{
			$this->count = $this->db->query($this->sql);
			return $this->count->num_rows;
		}catch(Exception $e){
			return 0;
		}
	}
}

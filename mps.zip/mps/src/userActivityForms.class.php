<?php
class userActivityForms{
	public function __construct($db){
		$this->db = $db;
	} 

	public function displayWalletForm(){
		$this->form = "<h2>Fund Your Wallet, ".$_SESSION['user']."</h2><form method='post'>";
		$this->form .= "<p>
			<label>Enter Card Details</label><br>
			<input type='text' value='5062986523305589146' required='required' name='card'>
		</p>";
		$this->form .= "<p>
			<label>Enter CVV(3 digits behind the card)</label><br>
			<input type='text' value='833' name='cvv'>
		</p>";
		$this->form .= "<p>
			<label>Enter Amount</label><br>
			<input type='text' required='required' name='amnt'>
		</p>";
		$this->form .= "<p>
			<label>Enter Pin</label><br>
			<input type='tel' required='required' value='1111' name='pin'>
		</p>";
		$this->form .= "<p>
			<input type='submit' name='updateWalletBtn' value='Submit'>
		</p>";
		$this->form .= "</form>";
		print $this->form;
	}

	public function getUserId(){
		$p = $_SESSION['phone'];
		$sql = "SELECT id FROM customers_tbl WHERE pri_phone = '$p'";
		foreach($this->db->getData($sql) as $d){
			return $d['id'];
		}
	}
	
	public function submitWalletForm(){
		if(isset($_POST['updateWalletBtn'])){
			$amnt = $this->db->cleanInput($_POST['amnt']);
			$cid = $this->getUserId();

			$date = date("Y-m-d H:i:s");
			$sql = "INSERT INTO transaction_tbl (customer_id,	amount_deposited,tans_status,trans_date) VALUES ('$cid','$amnt','1','$date')";
			$this->db->saveData($sql);
			$p = $_SESSION['phone'];
			$sql = "SELECT wallet FROM customers_tbl WHERE pri_phone = '$p'";
			$data = $this->db->getData($sql);
			foreach($data as $d){
				//get old wallet balance
				$owb = $d['wallet'];
				if($owb == ""){
					$owb = 0;
				}
				$nwb = $owb + $amnt;
				$this->db->updateData("UPDATE customers_tbl SET wallet = '$nwb' WHERE pri_phone = '$p'");
			}
			
			print '<script>alert("Your wallet has been credited successfully!");location.assign("../app");</script>';
		}
	}

	public function displayUpdateWalletForm(){

	}

	public function displayComplaintsWalletForm(){
		$this->form = "<h2>Lodge a Complaint</h2><form method='post'>";
		$this->form .= "<p>
			<label>Title</label><br>
			<input type='text' required='required' name='ctitle'>
		</p>";
		$this->form .= "<p>
			<label>Your Complaint</label><br>
			<textarea name='cbody' style='width:200px;height:100px'></textarea>
		</p>";
		
		$this->form .= "<p>
			<input type='submit' name='submitComplaintBtn' value='Submit'>
		</p>";
		$this->form .= "</form>";
		print $this->form;
	}

	public function submitComplaintForm(){
		if(isset($_POST['submitComplaintBtn'])){
			$body = $this->db->cleanInput($_POST['cbody']);
			$title = $this->db->cleanInput($_POST['ctitle']);
			$cid = $this->getUserId();
			$today = date("Y-m-d H:i:s");

			$sql = "INSERT INTO support_tbl (customer_id,title,complaint,date_sent) 
			VALUES 
			('$cid','$title','$body','$today')";

			if($this->db->saveData($sql) < 1){
				print '<script>alert("Ooops! Try again!");location.assign("../app?request=complaints");</script>';
			}else{
				print '<script>alert("Your ticket was submitted successfully!");location.assign("../app?request=complaints");</script>';
			}
		}
	}

	public function fetchComplaints(){
		$output = "<table border=1>
			<tr>
				<th>S/N</th>
				<th>Title</th>
				<th>Body</th>
				<th>Date Sent</th>
				<th>Status</th>
			</tr>";
		$cid = $this->getUserId();
		$data = $this->db->getData("SELECT * FROM support_tbl WHERE customer_id = '$cid' ORDER BY id DESC");
		$y = 0;
		foreach($data as $d){
			$y++;
			$status = $d['status'];
			if($status === 1){
				$status = "Read";
			}else{
				$status = "Unread";
			}
			$output.= '<tr>
				<td>'.$y.'</td>
				<td>'.$d['title'].'</td>
				<td>'.$d['complaint'].'</td>
				<td>'.$d['date_sent'].'</td>
				<td>'.$status.'</td>
			</tr>';
		}

		$output.= "</table>";
		
		print $output;
	}

	public function fetchBill(){
		$output = "<table border=1>
			<tr>
				<th>S/N</th>
				<th>Bills</th>
				<th>Amount</th>
				<th>Date Sent</th>
				<th>Status</th>
			</tr>";
		$cid = $this->getUserId();
		$data = $this->db->getData("SELECT * FROM bills WHERE customer_id = '$cid' ORDER BY id DESC");
		$y = 0;
		foreach($data as $d){
			$y++;
			$status = $d['status'];
			if($status === '1'){
				$status = "Successful";
			}else{
				$status = "Unsuccessful";
			}
			$output.= '<tr>
				<td>'.$y.'</td>
				<td>'.$d['bill'].'</td>
				<td>'.$d['amount'].'</td>
				<td>'.$d['date_paid'].'</td>
				<td>'.$status.'</td>
			</tr>';
		}

		$output.= "</table>";
		
		print $output;
	}

	public function displayBillForm(){
		$this->form = "<h2>Select a Bill to Pay</h2><form method='post'>";
		$this->form .= "<p>
			<label>Bill</label><br>
			<select required='required' name='bill'>
				<option></option>
				<option value='AEDC'>AEDC</option>
				<option value='DSTV'>DSTV</option>
				<option value='Airtime'>Airtime</div>
			</select>
		</p>";
		$this->form .= "<p>
			<label>Amount</label><br>
			<input type='number' required='required' name='amount' min='10'>
		</p>";
		
		$this->form .= "<p>
			<input type='submit' name='submitBillBtn' value='Submit'>
		</p>";
		$this->form .= "</form>";
		print $this->form;
	}

	public function submitBill(){
		if(isset($_POST['submitBillBtn'])){
			$bill = $this->db->cleanInput($_POST['bill']);
			$amount = $this->db->cleanInput($_POST['amount']);
			$date = date("Y-m-d H:i:s");
			$p = $_SESSION['phone'];
			$sql = "SELECT wallet FROM customers_tbl WHERE pri_phone = '$p'";
			$data = $this->db->getData($sql);
			foreach($data as $d){
				//get wallet balance
				$owb = $d['wallet'];

				if($amount > $owb){
					print '<script>alert("Insufficient fund!!!");</script>';
				}else{
					$nwb = $owb - $amount;
					//submit bill
					$cid = $this->getUserId();
					if($this->db->saveData("INSERT INTO bills 
						(bill,customer_id,amount,date_paid, status) 
						VALUES 
						('$bill','$cid','$amount','$date','1')") < 1){
						print '<script>alert("Oooops! Try again!!!");</script>';
					}else{
						$this->db->updateData("UPDATE customers_tbl SET wallet = '$nwb' WHERE id = '$cid'");
						print '<script>alert("Bill payment was successful!!!");location.assign("../app?request=payBill");</script>';
					}
				}
				
			}

		}
	}

}
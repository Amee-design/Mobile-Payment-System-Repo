<?php

class registration{
	public function __construct($db){
		$this->db = $db;
	}

	public function displayRegForm(){
		$this->form = "<h2>Customer Registration Form</h2><form method='post'>";
		$this->form .= "<p>
			<label>First Name*</label><br>
			<input type='text' required='required' name='cfn'>
		</p>";
		$this->form .= "<p>
			<label>Middle Name</label><br>
			<input type='text' name='cmn'>
		</p>";
		$this->form .= "<p>
			<label>Last Name*</label><br>
			<input type='text' required='required' name='cln'>
		</p>";
		$this->form .= "<p>
			<label>Phone*</label><br>
			<input type='tel' required='required' name='cphone'>
		</p>";
		$this->form .= "<p>
			<label>Password*</label><br>
			<input type='password' required='required' name='cpw'>
		</p>";
		$this->form .= "<p>
			<label>Confirm Password*</label><br>
			<input type='password' required='required' name='ccpw'>
		</p>";
		$this->form .= "<p>
			<input type='submit' name='submitRegBtn' value='Submit'>
		</p>";
		$this->form .= "</form>";
		print $this->form;
	}
	public function displayLoginForm(){
		$this->form = "<h2>Customer Login Form</h2><form method='post'>";
		
		$this->form .= "<p>
			<label>Phone</label><br>
			<input type='tel' required='required' name='cphone'>
		</p>";
		$this->form .= "<p>
			<label>Password</label><br>
			<input type='password' required='required' name='cpw'>
		</p>";
		
		$this->form .= "<p>
			<input type='submit' name='loginBtn' value='Log Me In'>
		</p>";
		$this->form .= "</form>";
		print $this->form;
	}
	
	public function loginCustomer(){
		if(isset($_POST['loginBtn'])){
			$phone = $this->db->cleanInput($_POST['cphone']);
			$pw = $this->db->cleanInput($_POST['cpw']); 

			$sql = "SELECT pw,fn,pri_phone FROM customers_tbl WHERE pri_phone = '$phone'";
			if($this->db->countRows($sql) < 1){
				print '<script>alert("Ooooops! It seems you are not a registered customer! You have to register to use this system!!!")</script>';
			}else{
				$data = $this->db->getData($sql);
				foreach($data as $d){
					$tbl_pw = $d['pw'];
					if(md5($pw) != $tbl_pw){
						print '<script>alert("Oooops! Either your phone number or your password does not match! Check your inputs!!!");</script>';
					}else{
						$_SESSION['user'] = $d['fn'];
						$_SESSION['phone'] = $d['pri_phone'];
						print '<script>location.assign("app");</script>';
						exit();
					}
				}
			}
			
		}
	}

	public function registerCustomer(){
		if(isset($_POST['submitRegBtn'])){
			$fn = $this->db->cleanInput($_POST['cfn']);
			$mn = $fn = $this->db->cleanInput($_POST['cmn']);
			$ln = $this->db->cleanInput($_POST['cln']);
			$phone = $this->db->cleanInput($_POST['cphone']);
			$pw = $this->db->cleanInput($_POST['cpw']);
			$password = md5($pw);
			$ccpw = $this->db->cleanInput($_POST['ccpw']);

			if($pw != $ccpw){
				print '<script>alert("Oooops! Your password does not match! Check your inputs!!!");</script>';
			}else{
				$today = date("Y-m-d H:i:s");
				$sql = "INSERT INTO customers_tbl (fn,mn,ln,pri_phone,pw,date_registered) 
				VALUES 
				('$fn','$mn','$ln','$phone','$password','$today')";
				if($this->validateCustomer($phone) == true){
					//proceed with user reg
					if($this->db->saveData($sql) < 1){
						$this->db->checkSql($sql);
						//print '<script>alert("Ooooops! We could not register you at this moment. Try again!!!")</script>';
					}else{
				
						print '<script>alert("Hello, "'.$fn.'", your registration was successful! Your password is "'.$pw.'");</script>';
					}
				}else{
					//customer already exists with details 
					//disable reg
					print '<script>alert("Ooooops! Your details already match an existing customer!!!")</script>';
				}
				
			}
		}
	}

	private function validateCustomer($p){
		$sql = "SELECT id FROM customers_tbl WHERE pri_phone = '$p'";
		if($this->db->countRows($sql) < 1){
			return true;
		}else{
			return false;
		}
	}
}
<?php
class userActivity{
	public function __construct($db){
		$this->db = $db;
	}
	public function getUserWallet(){
		$p = $_SESSION['phone'];
		$sql = "SELECT wallet FROM customers_tbl WHERE pri_phone = '$p'";
		foreach($this->db->getData($sql) as $d){
			//get old wallet balance
			return "NGN".$d['wallet'];
		}
	}
	public function logOut(){
		session_start();
		session_destroy();
		print '<script>location.assign("/mps");</script>';
		exit();
	} 
}
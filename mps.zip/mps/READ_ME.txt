This System application was written in php with mysql database  on a localhost (Xamp).

was written in Object Oriented Programming Approach in PHP with MySql database  managing the database system, methods and functions are called.
user Dashboard, Fund Wallet , Pay Bills and Support Ticket pages was created with a recorded database.

Users can fund their wallet from their bank account and select bills payment.
-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2021 at 06:48 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mps`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `id` int(11) NOT NULL,
  `fn` varchar(50) DEFAULT NULL,
  `mn` varchar(50) DEFAULT NULL,
  `ln` varchar(50) DEFAULT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pw` varchar(64) DEFAULT NULL,
  `date_registered` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bill` varchar(50) DEFAULT NULL,
  `amount` varchar(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `date_paid` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `customer_id`, `bill`, `amount`, `status`, `date_paid`) VALUES
(1, 1, 'AEDC', '2300', '0', '2021-02-17 00:04:57'),
(2, 1, 'DSTV', '10', '0', '2021-02-17 05:27:19'),
(3, 1, 'Airtime', '102', '1', '2021-02-17 06:02:09');

-- --------------------------------------------------------

--
-- Table structure for table `customers_tbl`
--

CREATE TABLE `customers_tbl` (
  `id` int(11) NOT NULL,
  `fn` varchar(50) DEFAULT NULL,
  `mn` varchar(50) DEFAULT NULL,
  `ln` varchar(50) DEFAULT NULL,
  `pri_phone` varchar(14) DEFAULT NULL,
  `pw` varchar(64) DEFAULT NULL,
  `wallet` varchar(11) DEFAULT '0',
  `date_registered` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers_tbl`
--

INSERT INTO `customers_tbl` (`id`, `fn`, `mn`, `ln`, `pri_phone`, `pw`, `wallet`, `date_registered`) VALUES
(1, 'Ameer', 'Ameer', 'Ayeh', '09059596416', '25d55ad283aa400af464c76d713c07ad', '3052.89', '2021-02-15 08:17:15');

-- --------------------------------------------------------

--
-- Table structure for table `phone_num_tbl`
--

CREATE TABLE `phone_num_tbl` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `carrier` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `support_tbl`
--

CREATE TABLE `support_tbl` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `complaint` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `date_sent` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `support_tbl`
--

INSERT INTO `support_tbl` (`id`, `title`, `customer_id`, `complaint`, `status`, `date_sent`) VALUES
(5, 'Hello', 1, 'Can you help me validate my phone number?', '0', '2021-02-16 23:40:54');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_tbl`
--

CREATE TABLE `transaction_tbl` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `amount_deposited` varchar(11) DEFAULT NULL,
  `tans_status` enum('0','1') DEFAULT '0',
  `trans_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_tbl`
--

INSERT INTO `transaction_tbl` (`id`, `customer_id`, `amount_deposited`, `tans_status`, `trans_date`) VALUES
(6, 1, '5230', '1', '2021-02-16 22:57:49'),
(7, 1, '200', '1', '2021-02-16 22:59:36'),
(8, 1, '34.89', '1', '2021-02-16 23:00:13');

-- --------------------------------------------------------

--
-- Table structure for table `vendors_tbl`
--

CREATE TABLE `vendors_tbl` (
  `id` int(11) NOT NULL,
  `v_name` varchar(10) DEFAULT NULL,
  `ussd` varchar(10) DEFAULT NULL,
  `num_format` int(6) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers_tbl`
--
ALTER TABLE `customers_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phone_num_tbl`
--
ALTER TABLE `phone_num_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_tbl`
--
ALTER TABLE `support_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_tbl`
--
ALTER TABLE `transaction_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors_tbl`
--
ALTER TABLE `vendors_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers_tbl`
--
ALTER TABLE `customers_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `phone_num_tbl`
--
ALTER TABLE `phone_num_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_tbl`
--
ALTER TABLE `support_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction_tbl`
--
ALTER TABLE `transaction_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vendors_tbl`
--
ALTER TABLE `vendors_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
